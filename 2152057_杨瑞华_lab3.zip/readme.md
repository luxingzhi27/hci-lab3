# HCI-lab3-dashboard

## how to run

To run the project, type the follow commands in cmd.

```shell
pip install dash pandas dash-bootstrap-components
python ./lab3-dashboard.py
```

Then type `http://127.0.0.1:8050/` in the browser and you can see the results.

![image-20230522200708694](https://raw.githubusercontent.com/luxingzhi27/picture/main/image-20230522200708694.png)